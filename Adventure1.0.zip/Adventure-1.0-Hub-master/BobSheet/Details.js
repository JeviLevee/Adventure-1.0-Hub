function Leftdet() {
  $("#detail").html("Nothing here.")
}

function Nodet() {
  $("#detail").html("Nothing here.")
}

function Rightdet() {
  $("#detail").html("Nothing here.")
}

function Medlfdet() {
  $("#detail").html("Heals 50 LF, and has a 2/6 chance to heal major wounds.")
}

function Pet1det() {
  $("#detail").html("A Thug Life Fish drawn naturally to Bob's speedy nature.")
}

function Platedet() {
  $("#detail").html("Buffing Boost:Any buffing skill has 50% mana cost.")
}

function Bobdet() {
  $("#detail").html("Bob is a speedy boi closely related to TurntSNACO from Middledale. Despite their disputes, they work well as a team.")
}

function CustomBuffDet() {
  $("#detail").html(write)
}
