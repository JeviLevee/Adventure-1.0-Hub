function Leftdet() {
  $("#detail").html("Urbosa's Fury:Does Lightning Elemental Damage")
}

function Nodet() {
  $("#detail").html("Nothing here.")
}

function Rightdet() {
  $("#detail").html("Bane of Nega:Does 1.5x Damage to Nega Enemies")
}

function Medlfdet() {
  $("#detail").html("Heals 50 LF, and has a 2/6 chance to heal major wounds.")
}

function Pet1det() {
  $("#detail").html("A treant sapling with the ability to create leaf tornadoes. It was found by the treant that attacked Niro's party when it was level 5.")
}

function Platedet() {
  $("#detail").html("Clean Status: 20% chance to remove all status effects on your turn")
}

function Nirodet() {
  $("#detail").html("Niro is an aspiring Ninja from Middledale, trying to finish his father's quest.")
}

function CustomBuffDet() {
  $("#detail").html(write)
}
