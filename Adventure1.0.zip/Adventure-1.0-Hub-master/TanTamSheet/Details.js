
function Nodet() {
  $("#detail").html("Nothing here.")
}

function Medlfdet() {
  $("#detail").html("Heals 50 LF, and has a 2/6 chance to heal major wounds.")
}

function TanTamdet() {
  $("#detail").html("Tan and Tam are a duo who bound their souls to achieve great power when together. They've been chosen to fight against the titan threat by the king.")
}

function CustomBuffDet() {
  $("#detail").html(write)
}
